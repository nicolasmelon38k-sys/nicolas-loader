const db = require('../db');

module.exports = {
    name: 'ban',
    execute: async (sock, msg, args) => {
        try {
            const remetente = msg.key.remoteJid;
            if (!remetente.endsWith('@g.us')) return sock.sendMessage(remetente, { text: "❌ Comando apenas para grupos." });

            const groupMetadata = await sock.groupMetadata(remetente);
            const admins = groupMetadata.participants.filter(p => p.admin !== null).map(p => p.id);
            const sender = msg.key.participant || msg.key.remoteJid;
            const senderIdNum = db.normalizarId(sender);
            
            // Verificação de Autoridade
            const isAuthorized = admins.includes(sender) || ['554896669255'].includes(senderIdNum) || msg.key.fromMe;
            if (!isAuthorized) return sock.sendMessage(remetente, { text: "⚠️ Você não tem poder para banir ninguém!" }, { quoted: msg });

            // Identificar Alvo (Menção ou Resposta)
            let alvo = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                       msg.message?.extendedTextMessage?.contextInfo?.participant;

            if (!alvo) return sock.sendMessage(remetente, { text: "❌ Marque alguém ou responda a mensagem de quem você quer banir!" }, { quoted: msg });

            const botId = sock.user.id.includes(':') ? sock.user.id.split(':')[0] + '@s.whatsapp.net' : sock.user.id;
            if (alvo === botId) return sock.sendMessage(remetente, { text: "🤣 Tá tentando me banir? Aí não né pai." }, { quoted: msg });

            // Verifica se o Bot é Admin
            const isBotAdmin = admins.includes(botId);
            if (!isBotAdmin) return sock.sendMessage(remetente, { text: "⚠️ Eu preciso ser Admin para expulsar alguém!" }, { quoted: msg });

            // Executa a Marretada
            await sock.groupParticipantsUpdate(remetente, [alvo], "remove");
            await sock.sendMessage(remetente, { text: `🚀 *MARRETADA APLICADA!*\n@${db.normalizarId(alvo)} foi removido com sucesso.`, mentions: [alvo] });

        } catch (e) {
            console.log("Erro no ban:", e);
            sock.sendMessage(msg.key.remoteJid, { text: "❌ Ocorreu um erro ao tentar banir." });
        }
    }
};
