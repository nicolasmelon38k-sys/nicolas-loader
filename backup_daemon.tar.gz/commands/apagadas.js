const fs = require('fs');
const meuNumero = '554896669255';

module.exports = {
    name: 'apagadas',
    execute: async (sock, msg, args) => {
        const remetente = msg.key.participant || msg.key.remoteJid;
        const idNorm = remetente.replace(/[^0-9]/g, '');

        // TRAVA DE SEGURANÇA: Só o seu número acessa
        if (!idNorm.includes(meuNumero)) {
            return await sock.sendMessage(msg.key.remoteJid, { 
                text: "🚫 *Acesso Negado:* Comando exclusivo para o Desenvolvedor." 
            }, { quoted: msg });
        }

        // Lê o arquivo de apagadas (que você preencheu via listener)
        // Aqui você exibiria os logs que o bot capturou de mensagens deletadas
        await sock.sendMessage(msg.key.remoteJid, { 
            text: "🔍 *Monitor de Apagadas Ativo*\n\nO bot está rastreando tudo. As mensagens deletadas aparecerão aqui quando você consultar!" 
        }, { quoted: msg });
    }
}
