const db = require('../db');
const { tabelaCartoes } = require('./cartao');

// Função para mascarar o CPF
function mascararCPF(cpf) {
    if (!cpf || cpf === "Não emitido") return "Não emitido";
    if (cpf.length >= 11) {
        return cpf.substring(0, 3) + ".***.***-" + cpf.substring(cpf.length - 2);
    }
    return "***.***.***-**";
}

module.exports = {
    name: 'perfil',
    execute: async (sock, msg, args) => {
        try {
            const remetente = msg.key.remoteJid;
            const alvoBruto = args.join(' ').trim();
            const id = db.normalizarId(alvoBruto || msg.key.participant || msg.key.remoteJid);
            const user = db.obterUsuario(id);

            if (!user) {
                return sock.sendMessage(remetente, { text: "❌ Usuário não encontrado no banco de dados." }, { quoted: msg });
            }
            const divida = Number(user.divida || 0);
            const statusDiv = divida > 0 ? `\n🚨 *DÍVIDA SPC:* R$ -${divida.toLocaleString('pt-BR')}` : `\n✅ *SITUAÇÃO:* Nome Limpo`;
            const fomeAtual = user.fome !== undefined ? user.fome : 10000;
            const pix = user.chavePix && user.chavePix !== "Não gerada" ? user.chavePix : "Não gerada";
            const cpfCensurado = mascararCPF(user.cpf);

            const cartaoAtivo = user.cartaoAtivo || "basico";
            const infoCard = (tabelaCartoes && tabelaCartoes[cartaoAtivo]) ? tabelaCartoes[cartaoAtivo] : { nome: "💳 Básico" };
            const fatura = user.faturas && user.faturas[cartaoAtivo] ? Number(user.faturas[cartaoAtivo]) : 0;
            
            // 🪙 PUXANDO AS MOEDAS VIP
            const moedasVip = user.moedas || 0;

            // TRATAMENTO VIP DO STATUS DE ROMANCE
            let statusDisplay = user.status || 'Solteiro(a)';
            if (statusDisplay.includes('@')) {
                const parts = statusDisplay.split('@'); // Divide a string "Namorando com " e "55489..."
                const partnerId = parts[1].trim();
                const partner = db.obterUsuario(partnerId);
                const partnerName = partner && partner.nome ? partner.nome : 'Desconhecido';

                // Junta tudo bonitinho: Namorando com *Nome Da Pessoa*
                statusDisplay = `${parts[0]}*${partnerName}*`;
            }

            const perfilLayout = `
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃         👤 PERFIL DO USUÁRIO
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

👤 *Nome:* ${user.nome || 'Usuário'}
🆔 *CPF:* ${cpfCensurado}
⭐ *Level:* ${user.level || 1}
✨ *XP:* ${(user.xp || 0).toLocaleString('pt-BR')}
🕊️ *Score Moral:* ${user.reputacao || 0} pts

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 *FINANÇAS*
💵 *Carteira:* R$ ${(user.dinheiro || 0).toLocaleString('pt-BR')}
🏦 *Banco:* R$ ${(user.banco || 0).toLocaleString('pt-BR')}
🪙 *Moedas VIP:* ${moedasVip.toLocaleString('pt-BR')}
🔑 *Chave Pix:* ${pix}${statusDiv}

💳 *CRÉDITO (Ativo)*
🏧 *Cartão:* ${infoCard.nome}
🧾 *Fatura:* R$ ${fatura.toLocaleString('pt-BR')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💼 *CARREIRA & SOBREVIVÊNCIA*
💼 *Emprego:* ${user.emprego || 'Desempregado'}
🍗 *Energia:* ${fomeAtual.toLocaleString('pt-BR')} / 10.000
💬 *Mensagens:* ${(user.mensagens || 0).toLocaleString('pt-BR')}
💞 *Status:* ${statusDisplay}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`.trim();

            await sock.sendMessage(remetente, { text: perfilLayout }, { quoted: msg });
        } catch (e) {
            console.error("Erro no Perfil:", e);
        }
    }
};
