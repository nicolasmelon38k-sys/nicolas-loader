process.on("uncaughtException", console.error);
process.on("unhandledRejection", console.error);

const {
    default: makeWASocket,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    DisconnectReason,
    makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");

const fs = require("fs");
const path = require("path");
const pino = require("pino");
const db = require("./db");

const commands = new Map();
const commandsPath = path.join(__dirname, "commands");

function loadCommands() {
    commands.clear();

    if (!fs.existsSync(commandsPath)) {
        console.log("❌ Pasta commands não existe");
        return;
    }

    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"));
    
    for (const file of commandFiles) {
        try {
            delete require.cache[require.resolve(`./commands/${file}`)];
            const cmd = require(`./commands/${file}`);

            if (cmd?.name && typeof cmd.execute === "function") {
                commands.set(cmd.name, cmd);
            }
        } catch (e) {
            console.log(`❌ erro no comando ${file}:`, e.message);
        }
    }
    console.log(`🚀 Total comandos carregados: ${commands.size}`);
}

function getText(msg) {
    const m = msg?.message;
    if (!m) return "";
    return (
        m.conversation ||
        m.extendedTextMessage?.text ||
        m.imageMessage?.caption ||
        m.videoMessage?.caption ||
        ""
    );
}

function tempo(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);

    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m ${s % 60}s`;
    return `${s}s`;
}

async function start() {
    const { state, saveCreds } = await useMultiFileAuthState("auth_info_baileys");
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" }))
        },
        printQRInTerminal: false,
        browser: ["Ubuntu", "Chrome", "20.0.04"], // Disfarce oficial para pareamento
        logger: pino({ level: "silent" })
    });

    // 📱 LÓGICA DO CÓDIGO DE PAREAMENTO (COM DELAY DE 4s ANTI-SPAM)
    if (!sock.authState.creds.registered) {
        console.log('⏳ Preparando para solicitar o código (Delay de 4s para estabilizar a rede)...');
        setTimeout(async () => {
            try {
                const numeroDoBot = "554896669255";
                const code = await sock.requestPairingCode(numeroDoBot);
                console.log('\n======================================================');
                console.log('📱 CÓDIGO DE PAREAMENTO DO WHATSAPP: ' + code);
                console.log('======================================================\n');
            } catch (err) {
                console.log('⚠️ Erro ao pedir o código:', err.message);
            }
        }, 4000);
    }

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (u) => {
        if (u.connection) console.log("🔌 connection:", u.connection);

        if (u.connection === "open") {
            console.log("🟢 BOT ONLINE (sessão ativa)");
        }

        if (u.connection === "close") {
            const code = u.lastDisconnect?.error?.output?.statusCode;
            console.log("🔴 desconectado (código):", code);

            if (code !== DisconnectReason.loggedOut) {
                start();
            }
        }
    });

    // 👋 BOAS-VINDAS ROBLOX (CORRIGIDO)
    sock.ev.on("group-participants.update", async (update) => {
        try {
            const { id, participants, action } = update;
            if (action === "add") {
                for (const part of participants) {
                    // BLINDAGEM: Verifica se o Baileys mandou o ID como string ou como objeto
                    const participanteJid = typeof part === 'string' ? part : (part.id || String(part));
                    const numeroLimpo = participanteJid.split('@')[0];
                    
                    const welcomeText = `~𝐒𝐄𝐉𝐀 𝐁𝐄𝐌 𝐕𝐈𝐍𝐃* @${numeroLimpo} \n𝐀𝐎 𝐆𝐑𝐔𝐏𝐎 𝐃𝐄 𝐑𝐎𝐁𝐋𝐎𝐗.\n\n𝐀𝐏𝐑𝐄𝐒𝐄𝐍𝐓𝐄-𝐒𝐄 𝐂𝐎𝐌..\n\n𝐅𝐎𝐓𝐎(𝐎𝐏𝐂𝐈𝐎𝐍𝐀𝐋):\n𝐍𝐎𝐌𝐄:\n𝐈𝐃𝐀𝐃𝐄:\n𝐄𝐒𝐓𝐀𝐃𝐎:\n𝐏𝐑𝐎𝐍𝐎𝐌𝐄𝐒:\n𝐍𝐈𝐂𝐊 𝐃𝐎 𝐉𝐎𝐆𝐎:\n\n𝐒𝐄 𝐕𝐂 𝐓𝐈𝐕𝐄𝐑 𝐀𝐋𝐆𝐔𝐌𝐀 𝐃𝐄𝐅𝐈𝐂𝐈𝐄𝐍𝐂𝐈𝐀 𝐎𝐔 𝐏𝐑𝐎𝐁𝐋𝐄𝐌𝐀 𝐏𝐅𝐕 𝐈𝐍𝐅𝐎𝐑𝐌𝐄 𝐎𝐃 𝐀𝐃𝐌𝐒 𝐏𝐀𝐑𝐀 𝐍 𝐓𝐄𝐑 𝐏𝐑𝐎𝐁𝐋𝐄𝐌𝐀𝐒 𝐅𝐔𝐓𝐔𝐑𝐎𝐒.\n\n𝐀𝐇 𝐄 𝐀 𝐆𝐄𝐍𝐓𝐄 𝐓𝐄𝐌 𝐔𝐌 𝐂𝐀𝐍𝐀𝐋 𝐃𝐎 𝐆𝐑𝐔𝐏𝐎 𝐏𝐀𝐑𝐀 𝐕𝐂 𝐄𝐍𝐓𝐑𝐀𝐑 𝐄 𝐒𝐀𝐁𝐄𝐑 𝐓𝐔𝐃𝐎 𝐎𝐐𝐔𝐄 𝐓𝐈𝐕𝐄𝐑 𝐀𝐂𝐎𝐍𝐓𝐄𝐂𝐄𝐍𝐃𝐎 𝐄𝐍𝐓𝐀𝐎 𝐉𝐀 𝐕𝐀𝐈 𝐄𝐍𝐓𝐑𝐀𝐍𝐃𝐎!!\n\nSiga o canal "✧꧁༺★𝐑𝐎𝐁𝐋𝐎𝐗★༻꧂✧" no WhatsApp: https://whatsapp.com/channel/0029Vb7mHZuISTkPnzFHOG1m`;
                    
                    await sock.sendMessage(id, { text: welcomeText, mentions: [participanteJid] });
                }
            }
        } catch (err) {
            console.log("❌ Erro nas boas vindas:", err.message);
        }
    });

    sock.ev.on("messages.upsert", async (m) => {
        if (m.type !== 'notify' && m.type !== 'append') return;

        for (const msg of m.messages) {
            try {
                if (!msg.message || msg.key.remoteJid === "status@broadcast") continue;

                const body = getText(msg);
                const jid = msg.key.remoteJid;
                const isGroup = jid.endsWith('@g.us');
                
                // 🛑 FORÇA A LEITURA CORRETA DO SEU PRÓPRIO NÚMERO
                let sender;
                if (msg.key.fromMe) {
                    sender = sock.user.id.split(':')[0] + "@s.whatsapp.net";
                } else {
                    sender = msg.key.participant || msg.key.remoteJid;
                }
                
                const id = db.normalizarId(sender);

                // 🛑 SISTEMA ANTI-LINK TRANSISTOR NO MOTOR
                if (isGroup && body) {
                    const gruposPath = './grupos.json';
                    if (!fs.existsSync(gruposPath)) fs.writeFileSync(gruposPath, JSON.stringify({}));
                    const grupos = JSON.parse(fs.readFileSync(gruposPath, 'utf8'));
                    const configGrupo = grupos[jid] || {};
                    const antiLinkAtivo = configGrupo.antilink === true || configGrupo['anti-link'] === true;
                    
                    if (antiLinkAtivo && /(https?:\/\/|chat\.whatsapp\.com|wa\.me)/i.test(body)) {
                        const groupMetadata = await sock.groupMetadata(jid);
                        const senderLimpo = sender.split('@')[0];
                        const isAdmin = groupMetadata.participants.find(p => p.id.startsWith(senderLimpo))?.admin !== null;
                        const isDonoBot = senderLimpo === '554896669255';
                        const isImmune = isAdmin || isDonoBot || msg.key.fromMe;

                        const botLimpo = sock.user?.id?.split(':')[0];
                        const isBotAdmin = groupMetadata.participants.find(p => p.id.startsWith(botLimpo))?.admin !== null;

                        if (!isImmune) {
                            if (isBotAdmin) {
                                await sock.sendMessage(jid, { delete: msg.key });
                                await sock.sendMessage(jid, { text: "⚠️ Você não leu as regras? Não é permitido enviar links!", mentions: [sender] });
                                await sock.groupParticipantsUpdate(jid, [sender], "remove");
                            }
                            continue; // Interrompe o processamento se for um link de infrator
                        }
                    }
                }

                const user = db.obterUsuario(id);

                // 🔥 SAIR DO AFK AUTOMÁTICO
                if (user?.afk?.status) {
                    const diff = Date.now() - user.afk.desde;
                    db.salvar(id, { afk: { status: false, motivo: "", desde: 0 } });
                    await sock.sendMessage(jid, { text: `👋 *Bem-vindo de volta!*\n⏳ Você ficou AFK por: ${tempo(diff)}` }, { quoted: msg });
                    console.log("🔁 AFK removido:", id);
                }

                // 🔥 AVISAR MENCIONADO AFK
                const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                for (const mId of mentions) {
                    const mid = db.normalizarId(mId);
                    const u = db.obterUsuario(mid);
                    if (u?.afk?.status) {
                        await sock.sendMessage(jid, { text: `💤 Esse usuário está AFK\n📝 Motivo: ${u.afk.motivo}` }, { quoted: msg });
                    }
                }

                if (!body.startsWith("!")) continue;

                const args = body.slice(1).trim().split(/ +/);
                const cmdName = args.shift().toLowerCase();
                const cmd = commands.get(cmdName);

                if (!cmd) {
                    console.log(`❌ Comando [${cmdName}] não encontrado.`);
                    continue;
                }

                console.log(`⚡ EXECUTANDO CMD: ${cmdName} | Solicitado por: ${id}`);
                await cmd.execute(sock, msg, args);
                console.log(`✅ CMD SUCESSO: ${cmdName}`);

            } catch (e) {
                console.log(`🔴 ERRO NA MENSAGEM:`, e.message);
            }
        }
    });

    loadCommands();
}

start();
